/* ********* */
/* You can use this file to define the low-level hardware control fcts for       */
/* LED, button and LCD devices.                                                  */ 
/* Note that these need to be implemented in Assembler.                          */
/* You can use inline Assembler code, or use a stand-alone Assembler file.       */
/* Alternatively, you can implement all fcts directly in master-mind.c,          */  
/* using inline Assembler code there.                                            */
/* The Makefile assumes you define the functions here.                           */
/* ********* */

#ifndef TRUE
#  define TRUE (1==1)
#  define FALSE (1==2)
#endif

#define PAGE_SIZE   (4*1024)
#define BLOCK_SIZE  (4*1024)

#define INPUT   0
#define OUTPUT  1
#define LOW     0
#define HIGH    1

// APP constants   ---------------------------------

// Wiring (see call to lcdInit in main, using BCM numbering)
// NB: this needs to match the wiring as defined in master-mind.c

#define STRB_PIN  24
#define RS_PIN    25
#define DATA0_PIN 23
#define DATA1_PIN 10
#define DATA2_PIN 27
#define DATA3_PIN 22

// -----------------------------------------------------------------------------
// includes 
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/types.h>

// Declare delay to avoid linker error
// extern void delay(int milliseconds); // function to delay execution for a specified number of milliseconds

// -----------------------------------------------------------------------------
// prototypes

 int failure (int fatal, const char *message, ...);

 // -----------------------------------------------------------------------------
 // Functions to implement here (or directly in master-mind.c)

 /* this version needs gpio as argument, because it is in a separate file */
 void digitalWrite (uint32_t *gpio, int pin, int value) {
   int off, res;
   off = (value == LOW) ? 10 : 7; // 10 = GPCLR0, 7 = GPSET0

   asm volatile(
     "MOV R1, %[gpio]\n" // Load gpio base address into R1.
     "ADD R0, R1, %[off]\n" // Compute address offset for set/clear register.
     "MOV R2, #1\n" // Set bit mask.
     "MOV R1, %[pin]\n" // Load pin number into R1.
     "AND R1, #31\n" // Ensure pin number is within valid range.
     "LSL R2, R1\n" // Shift bit to the correct pin position.
     "STR R2, [R0, #0]\n" // Write to register to set/clear the pin.
     "MOV %[result], R2\n" // Store result.
     : [result] "=r"(res)
     : [pin] "r"(pin), [gpio] "r"(gpio), [off] "r"(off * 4)
     : "r0", "r1", "r2", "cc"
   );
 }

 // adapted from setPinMode
 void pinMode(uint32_t *gpio, int pin, int mode) {
   int fSel = pin / 10; // Determine function select register index.
   int shift = (pin % 10) * 3; // Determine bit position shift for pin mode.
   int res;

   if (mode == OUTPUT) {
     asm volatile(
       "\tMOV R1, %[gpio]\n" // Load gpio base address into R1.          
       "\tADD R0, R1, %[fSel]\n" // Compute function select register address.
       "\tLDR R1, [R0, #0]\n" // Load current register value.
       "\tMOV R2, #0b111\n" // Prepare mask for clearing pin function bits.
       "\tLSL R2, %[shift]\n" // Shift mask to correct position.
       "\tBIC R1, R1, R2\n" // Clear pin function bits.
       "\tMOV R2, #1\n" // Set output mode.
       "\tLSL R2, %[shift]\n" // Shift bit to correct position.
       "\tORR R1, R2\n" // Apply new mode setting.
       "\tSTR R1, [R0, #0]\n" // Write back to register.
       "\tMOV %[result], R1\n" // Store result.
       : [result] "=r"(res)
       : [pin] "r"(pin), [gpio] "r"(gpio), [fSel] "r"(fSel * 4), [shift] "r"(shift)
       : "r0", "r1", "r2", "cc"
     );
   }
 }

 void writeLED(uint32_t *gpio, int led, int value) {
   digitalWrite(gpio, led, value); // reuse digitalWrite
 }

 // Debounced readButton
 int readButton(uint32_t *gpio, int button) {
   int state = 0;
   int stable = 0;

   for (int i = 0; i < 3; i++) {
     asm volatile(
       "MOV R1, %[gpio]\n" // Load gpio base address into R1.
       "LDR R2, [R1, #0x34]\n" // Load GPIO input level register.
       "MOV R3, %[pin]\n" // Load pin number.
       "MOV R4, #1\n" // Prepare mask for pin state check.
       "LSL R4, R3\n" // Shift mask to pin position.
       "AND %[state], R2, R4\n" // Extract pin state.
       : [state] "=r"(state)
       : [pin] "r"(button), [gpio] "r"(gpio)
       : "r1", "r2", "r3", "r4", "cc"
     );

     if (state > 0) stable++; // Count stable readings.
     delay(50);  // debounce delay
   }

   return (stable >= 2); // confirm if pressed
 }

 void waitForButton(uint32_t *gpio, int button) {
  fprintf(stdout, "Waiting for Player input...\n");
   for (int j = 0; j < 200; j++) {
     if (readButton(gpio, button)) // Check if button is pressed.
       break;
     delay(200); // Wait before next check.
   }
}